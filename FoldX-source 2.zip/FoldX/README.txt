FoldX - Author: Claude
Build: cần Theos bản roothide (roothide/theos). Trong thư mục này chạy:  make package
Ra file .deb trong thư mục packages/. Cài bằng Sileo/Filza rồi respring.
