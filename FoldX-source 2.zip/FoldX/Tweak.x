// FoldX - iPhone X "foldable" mode for SpringBoard (iOS 16, roothide)
// Author: Claude
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

#define PREF_DOMAIN @"com.claude.foldx"
#define PREF_NOTIFY "com.claude.foldx/prefschanged"

static BOOL gEnabled = YES;
static NSInteger gStyle = 3;      // 0 none, 1 fade, 2 slide, 3 unfold, 4 spring
static CGFloat gDuration = 0.55;
static BOOL gSwapHinge = NO;
static BOOL gLandscape = NO;      // true = "inner screen" mode

static void FXLoadPrefs(void) {
    NSUserDefaults *d = [[NSUserDefaults alloc] initWithSuiteName:PREF_DOMAIN];
    id v;
    gEnabled   = (v = [d objectForKey:@"enabled"])  ? [v boolValue]    : YES;
    gStyle     = (v = [d objectForKey:@"style"])    ? [v integerValue] : 3;
    gDuration  = (v = [d objectForKey:@"duration"]) ? [v doubleValue]  : 0.55;
    gSwapHinge = [[d objectForKey:@"swapHinge"] boolValue];
}

static void FXPrefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *obj, CFDictionaryRef u) {
    FXLoadPrefs();
}

// ---------- private interfaces ----------
@interface SBFolderView : UIView
@property (nonatomic, readonly) UIScrollView *scrollView;
- (NSArray *)iconListViews;
@end
@interface SBHomeScreenViewController : UIViewController @end
@interface SBDockView : UIView @end
@interface SBIconView : UIView @end

// ---------- helpers ----------
static void FXCollectIconViews(UIView *root, NSMutableArray *out) {
    for (UIView *s in root.subviews) {
        if ([s isKindOfClass:objc_getClass("SBIconView")]) [out addObject:s];
        else FXCollectIconViews(s, out);
    }
}

static void FXPlayAnimation(UIView *view) {
    if (gStyle == 0 || !view) return;
    CGFloat W = view.bounds.size.width;
    UIDeviceOrientation o = [UIDevice currentDevice].orientation;
    BOOL left = (o == UIDeviceOrientationLandscapeLeft);
    if (gSwapHinge) left = !left;
    CGFloat dir = left ? -1.0 : 1.0;
    CFTimeInterval dur = gDuration;

    switch (gStyle) {
        case 1: { // fade
            CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"opacity"];
            a.fromValue = @0; a.toValue = @1; a.duration = dur;
            [view.layer addAnimation:a forKey:@"fx"];
        } break;
        case 2: { // slide
            CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"transform.translation.x"];
            a.fromValue = @(dir * W * 0.35); a.toValue = @0;
            a.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
            CABasicAnimation *b = [CABasicAnimation animationWithKeyPath:@"opacity"];
            b.fromValue = @0; b.toValue = @1;
            CAAnimationGroup *g = [CAAnimationGroup animation];
            g.animations = @[a, b]; g.duration = dur;
            [view.layer addAnimation:g forKey:@"fx"];
        } break;
        case 3: { // unfold around a hinge on the left/right edge
            CGFloat hx = dir * (W / 2.0);
            CATransform3D t = CATransform3DIdentity;
            t.m34 = -1.0 / 900.0;
            t = CATransform3DTranslate(t, hx, 0, 0);
            t = CATransform3DRotate(t, dir * (M_PI / 2.0) * -1.0, 0, 1, 0);
            t = CATransform3DTranslate(t, -hx, 0, 0);
            CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"transform"];
            a.fromValue = [NSValue valueWithCATransform3D:t];
            a.toValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
            a.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
            CABasicAnimation *b = [CABasicAnimation animationWithKeyPath:@"opacity"];
            b.fromValue = @0.2; b.toValue = @1;
            CAAnimationGroup *g = [CAAnimationGroup animation];
            g.animations = @[a, b]; g.duration = dur;
            [view.layer addAnimation:g forKey:@"fx"];
        } break;
        case 4: { // spring scale
            CASpringAnimation *a = [CASpringAnimation animationWithKeyPath:@"transform.scale"];
            a.fromValue = @0.88; a.toValue = @1;
            a.mass = 1; a.stiffness = 180; a.damping = 14;
            a.duration = MAX(dur, a.settlingDuration);
            [view.layer addAnimation:a forKey:@"fx"];
        } break;
    }
}

// ---------- 1. unlock rotation on the home screen + animation ----------
%hook SBHomeScreenViewController
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return gEnabled ? (UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscape) : %orig;
}
- (BOOL)shouldAutorotate {
    return gEnabled ? YES : %orig;
}
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coord {
    if (gEnabled) gLandscape = (size.width > size.height);
    %orig;
    if (!gEnabled) return;
    __weak UIViewController *weakSelf = self;
    [coord animateAlongsideTransition:nil completion:^(id<UIViewControllerTransitionCoordinatorContext> ctx) {
        UIViewController *s = weakSelf;
        if (s) FXPlayAnimation(s.view);
    }];
}
%end

// Some builds route rotation permission through the icon controller as well
%hook SBIconController
- (BOOL)supportsRotation { return gEnabled ? YES : %orig; }
%end

// ---------- 2. two pages per screen in landscape ----------
%hook SBFolderView
- (void)layoutSubviews {
    %orig;
    if (!gEnabled || !gLandscape) return;
    if (![self isKindOfClass:objc_getClass("SBRootFolderView")]) return;

    NSArray *lists = [self iconListViews];
    if (lists.count == 0) return;
    CGFloat W = self.bounds.size.width;
    CGFloat dockReserve = 96.0;                       // space kept for the right-hand dock
    CGFloat usable = W - dockReserve;
    CGFloat half = usable / 2.0;
    CGFloat pageW = W;                                 // one swipe = one "pair" of pages

    for (NSUInteger i = 0; i < lists.count; i++) {
        UIView *l = lists[i];
        NSUInteger pair = i / 2, slot = i % 2;
        CGRect f = l.frame;
        f.origin.x = pair * pageW + slot * half;
        f.size.width = half;
        l.frame = f;
    }
    NSUInteger pairs = (lists.count + 1) / 2;
    UIScrollView *sv = self.scrollView;
    sv.contentSize = CGSizeMake(pairs * pageW, sv.contentSize.height);
}
%end

// ---------- 3. dock moves to the right-centre in landscape ----------
%hook SBDockView
- (void)layoutSubviews {
    %orig;
    if (!gEnabled || !gLandscape) return;
    UIView *p = self.superview;
    if (!p) return;

    CGRect pb = p.bounds;
    UIEdgeInsets in = p.safeAreaInsets;
    NSMutableArray *icons = [NSMutableArray array];
    FXCollectIconViews(self, icons);
    if (icons.count == 0) return;

    CGFloat w = 84.0;
    CGFloat h = MIN(pb.size.height - 60.0, icons.count * 84.0 + 20.0);
    CGRect target = CGRectMake(CGRectGetMaxX(pb) - w - MAX(in.right, 8.0),
                               (pb.size.height - h) / 2.0, w, h);
    if (!CGRectEqualToRect(self.frame, target)) self.frame = target;

    for (UIView *s in self.subviews) {
        if (![s isKindOfClass:objc_getClass("SBDockIconListView")] &&
            ![s isKindOfClass:objc_getClass("SBIconListView")]) {
            s.frame = self.bounds;                     // background blur
        }
    }
    self.layer.cornerRadius = 30.0;
    self.clipsToBounds = YES;

    [icons sortUsingComparator:^NSComparisonResult(UIView *a, UIView *b) {
        CGPoint pa = [a.superview convertPoint:a.center toView:self];
        CGPoint pb2 = [b.superview convertPoint:b.center toView:self];
        return pa.x < pb2.x ? NSOrderedAscending : NSOrderedDescending;
    }];
    CGFloat step = h / icons.count;
    for (NSUInteger i = 0; i < icons.count; i++) {
        UIView *iv = icons[i];
        CGPoint c = [self convertPoint:CGPointMake(w / 2.0, step * (i + 0.5)) toView:iv.superview];
        iv.center = c;
    }
}
%end

// ---------- 4. status bar: time left, wifi/battery merged right ----------
// Uses the notch ("split") layout in landscape too. Selector names are private
// and may need adjusting after class-dumping iOS 16.7 on the device.
%hook _UIStatusBar
+ (Class)visualProviderClassForScreen:(UIScreen *)screen {
    if (gEnabled && gLandscape) {
        Class split = objc_getClass("_UIStatusBarVisualProvider_Split");
        if (split) return split;
    }
    return %orig;
}
%end

%ctor {
    FXLoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
        FXPrefsChanged, CFSTR(PREF_NOTIFY), NULL, CFNotificationSuspensionBehaviorCoalesce);
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
}
