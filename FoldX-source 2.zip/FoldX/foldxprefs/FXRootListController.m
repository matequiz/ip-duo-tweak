#import <Preferences/PSListController.h>

@interface FXRootListController : PSListController
@end

@implementation FXRootListController
- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}
@end
