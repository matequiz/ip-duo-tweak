#!/bin/bash
# Gộp .deb Duo (đã việt hóa) + .deb FoldX thành 1 gói.
# Dùng: bash merge.sh duo.deb foldx.deb [ra.deb]
set -e
DUO="$1"; FOLD="$2"; OUT="${3:-merged.deb}"
W="$(mktemp -d)"
dpkg-deb -R "$DUO" "$W/duo"
dpkg-deb -R "$FOLD" "$W/fold"

# giữ nguyên script cài đặt nếu FoldX có mà Duo chưa có
for s in preinst postinst prerm postrm; do
  if [ -f "$W/fold/DEBIAN/$s" ] && [ ! -f "$W/duo/DEBIAN/$s" ]; then
    cp -a "$W/fold/DEBIAN/$s" "$W/duo/DEBIAN/$s"
  fi
done

# chép file của FoldX vào cây thư mục của Duo (giữ symlink)
rm -rf "$W/fold/DEBIAN"
cp -a "$W/fold/." "$W/duo/"

# viết lại control
python3 - "$W/duo/DEBIAN/control" <<'PY'
import re, sys
fn = sys.argv[1]
s = open(fn, encoding="utf8").read()
def setf(k, v):
    global s
    if re.search(r"^%s:.*$" % k, s, flags=re.M):
        s = re.sub(r"^%s:.*$" % k, "%s: %s" % (k, v), s, flags=re.M)
    else:
        s = s.rstrip("\n") + "\n%s: %s\n" % (k, v)
setf("Package", "com.claude.iphoneduo-foldx")
setf("Name", "IphoneDuoIcons(forIphoneDuoLockScreen-Tweak) + FoldX")
setf("Version", "1.1.0-vi1")
setf("Author", "OaksTheAwesome (Solo), Claude (FoldX)")
setf("Description", "Solo phỏng theo màn hình chính iPhone Duo (Việt hóa) gộp cùng FoldX: xoay ngang = màn hình trong 2 trang, dock bên phải, có animation.")
setf("Conflicts", "com.cydiabc.solo-rootless, com.claude.foldx")
setf("Replaces", "com.cydiabc.solo-rootless, com.claude.foldx")
s = re.sub(r"^Installed-Size:.*\n", "", s, flags=re.M)
open(fn, "w", encoding="utf8").write(s)
PY

dpkg-deb --root-owner-group -Zgzip -b "$W/duo" "$OUT"
echo "Đã tạo: $OUT"
